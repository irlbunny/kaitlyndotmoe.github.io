<?php
require_once('nex.functions.php');
$action = nex_base64_decode($_POST['action']);

switch ($action) {
  case 'LOGIN':
    $server_ip = '<your nex serverip>:6000';
    $date_time = 19700101000000;
    echo('locator='.nex_base64_encode($server_ip).'&retry=MA**&returncd=MDAx&token=MDAx**&datetime='.nex_base64_encode($date_time));
    break;
  default:
    nex_log(2, 'The action ['.$action.'] is un-implemented!');
    break;
}
exit;
