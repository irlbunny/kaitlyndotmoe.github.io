<?php
function nex_base64_encode($val) {
  return str_replace('=','*',base64_encode($val));
}
function nex_base64_decode($val) {
  return base64_decode(str_replace('=','*',$val));
}
function nex_log($severity = 0, $error = 'Unknown error') {
  //
  $severity_str = '';
  switch ($severity) {
    case 0:
      $severity_str = '[~]';
      break;
    case 1:
      $severity_str = '[@]';
      break;
    case 2:
      $severity_str = '[*]';
      break;
    case 3:
      $severity_str = '[!]';
      break;
    default:
      $severity_str = '[?]';
      break;
  }
  file_put_contents('nex_log.txt', $severity_str.' '.$error."\r\n");
}
