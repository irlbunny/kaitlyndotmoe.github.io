<?php
require_once('AltoRouter.php');
$router = new AltoRouter();
header('Content-Type: text/plain;charset=ISO-8859-1');

$router->addRoutes(array(
	array('GET|POST', '/ac', 'ac.php', 'Nex-ac')
));

$match = $router->match(urldecode($_SERVER['REQUEST_URI']));
if ($match) {
	foreach ($match['params'] as &$param) {
		${key($match['params'])} = $param;
	}
	require_once $match['target'];
} else {
	exit;
}
