# What is this?
Well duh, my attempt at a (horribly bodged) NEX server in PHP which uses PHP sockets.

# How do I use this?
You don't. Point is, this is intended for developers.

# What is NEX?
NEX is Nintendo's game server used on 3DS and Wii U for online multiplayer gaming stuff.

# Pull Requests
If you'd like to make a pull request make sure it's actually a needed PR and works, if it follows these terms, I might merge it.
