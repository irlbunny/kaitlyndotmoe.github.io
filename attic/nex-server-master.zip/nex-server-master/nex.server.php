<?php
error_reporting(~E_WARNING);

if (!($sock = socket_create(AF_INET, SOCK_DGRAM, 0))) {
    $errorcode = socket_last_error();
    $errormsg = socket_strerror($errorcode);

    die('SOCKET_CREATE_ERROR' . "\r\n");
}

echo 'SOCKET_CREATE_OK' . "\r\n";

if (!socket_bind($sock, '0.0.0.0', 6000)) {
    $errorcode = socket_last_error();
    $errormsg = socket_strerror($errorcode);

    die('SOCKET_BIND_ERROR' . "\r\n");
}

echo 'SOCKET_BIND_OK' . "\r\n";

while (1) {
    $data = socket_recvfrom($sock, $buf, 512, 0, $ip, $port);
    $client_packet = substr(substr(bin2hex($buf), 4), 0, -26);
    echo 'PACKET_RECIEVED: ' . $client_packet . "\r\n";
    switch ($client_packet) {
      case '40':
        $server_packet = hex2bin('a1af10' . str_repeat('00', 8) . '5f2268ea3a');
        socket_sendto($sock, $server_packet, 100, 0, $ip, $port);
        echo 'SENT_HANDSHAKE_1' . "\r\n";
        break;
      case '61':
        $server_packet = hex2bin('a1af110050d4d691e801' . str_repeat('00', 5) . 'de');
        socket_sendto($sock, $server_packet, 100, 0, $ip, $port);
        echo 'SENT_HANDSHAKE_2' . "\r\n";
        break;
      default:
        echo 'PACKET_UNIMPLEMENTED: ' . $client_packet . "\r\n";
        break;
    }
}

socket_close($sock);
