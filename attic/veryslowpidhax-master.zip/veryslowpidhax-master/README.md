# veryslowpidhax
A k11 exploit for the 3DS.

## Version Support
| Version | N3DS | O3DS/2DS |
| --- | --- | --- |
| US 11.2?-11.3 | ? | ✓ |


## Credit
Anonymous - (I don't know who originally made this so I listed him as Anonymous) Originally made this I simply just cleaned up his work.
