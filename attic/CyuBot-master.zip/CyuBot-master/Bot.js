const FirstTimeSetup = new (require('./FirstTimeSetup.js'))();
const Config = require('./config.json');
const Discord = require('discord.js');
const CommandParser = new (require('./CommandParser.js'))(Config);
const Client = new Discord.Client();

Config.GitBranch = require('child_process').execSync('git rev-parse --abbrev-ref HEAD').toString().trim();
Config.GitRevision = require('child_process').execSync('git rev-parse --short HEAD').toString().trim();

String.prototype.toHHMMSS = function () {
    var SecNum = parseInt(this, 10);
    var Hours   = Math.floor(SecNum / 3600);
    var Minutes = Math.floor((SecNum - (Hours * 3600)) / 60);
    var Seconds = SecNum - (Hours * 3600) - (Minutes * 60);

    if (Hours   < 10) { Hours   = '0' + Hours;   }
    if (Minutes < 10) { Minutes = '0' + Minutes; }
    if (Seconds < 10) { Seconds = '0' + Seconds; }
    return Hours + ':' + Minutes + ':' + Seconds;
}

Client.on('ready', () => {
	console.log('Logged in as %s - %s\n', Client.user.username, Client.user.id);
});

Client.on('message', (message) => {
	try {
		let MessageContext     = {};
		MessageContext.config  = Config;
		MessageContext.client  = Client;
		MessageContext.user    = message.author;
		MessageContext.message = message;
		
		CommandParser.Parse(MessageContext);
	}
	catch (e) {
		message.reply(':warning: Error - ' + e.message);
	}
});

Client.login(Config.DiscordToken);