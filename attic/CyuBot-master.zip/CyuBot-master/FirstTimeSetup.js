const fs = require('fs');
const readline = require('readline');
const ConsoleInput = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let FinalizedConfig = JSON.parse(fs.readFileSync('./config.json.example', 'utf8'));

class FirstTimeSetup {
    constructor() {
        if (fs.existsSync('./config.json')) return;
        console.log('------------ FTS (First Time Setup) ------------');
        this.Step1();
        this.Step2();
        fs.writeFile('./config.json', JSON.stringify(FinalizedConfig), 'utf8');
        console.log('FTS is done, starting bot!');
    }

    DiscordToken() {
        ConsoleInput.question('What is your Discord bot token? ', (token) => {
            return token;
        });
        return '';
    }

    Step1() {
        const TokenOutput = this.DiscordToken();
        if (TokenOutput != '') {
            FinalizedConfig.DiscordToken = TokenOutput;
            console.log('OK!');
        }
        else {
            console.log('Invalid Discord token, canceling setup!');
            process.exit(1);
        }
    }

    Step2() {
        ConsoleInput.question('What do you want your Discord bot prefix to be (Default = %)? ', (prefix) => {
            if (prefix != '') {
                FinalizedConfig.BotPrefix = prefix;
            }
            console.log('OK!');
        });
    }
}

module.exports = FirstTimeSetup;