const Commands = require('./Commands.js');

let Config = {};

class CommandParser {
	constructor(InternalConfig) {
		Config = InternalConfig;
	}

	Parse(MessageContext) {
		if (MessageContext.client.user.id == MessageContext.user.id) return;
		if (!MessageContext.message.content.startsWith(Config.BotPrefix)) return;
		MessageContext.command = MessageContext.message.content.substr(1).split(' ')[0];

		// Help and Commands are added by default
		if (MessageContext.command == 'help' || MessageContext.command == 'commands') {
			let commandsMessage = '**__Commands:__**\n';

			commandsMessage += '```';
			let sortedCommands = Object.keys(Commands).sort();

			for (var i in sortedCommands) {
				const sortedCommand = sortedCommands[i];
				commandsMessage += sortedCommand;

				// Usage
				if (Commands[sortedCommand].usage) {
					commandsMessage += ' - ' + Commands[sortedCommand].usage;
				}

				// Description
				if (Commands[sortedCommand].description) {
					commandsMessage += ' - ' + Commands[sortedCommand].description;
				}

				commandsMessage += '\n';
			}

			commandsMessage += '```';

			// Send help/commands message
			MessageContext.message.reply(commandsMessage);
			return;
		}

		// Try command, command args
		const Command = Commands[MessageContext.command];
		MessageContext.commandArgs = MessageContext.message.content.split(' ').slice(1);

		if (Command) {
			// I'll eventually clean this up
			if (!Command.argsCount) Command.argsCount = 0;
			if (MessageContext.commandArgs.length > Command.argsCount) {
				// Proper english
				if (Command.argsCount != 1) {
					throw new Error('This command requires ' + Command.argsCount + ' arguments, not ' + MessageContext.commandArgs.length + '.');
				}
				else {
					throw new Error('This command requires ' + Command.argsCount + ' argument, not ' + MessageContext.commandArgs.length + '.');
				}
			}

			if (MessageContext.commandArgs.length < Command.argsCount) {
				// Proper english
				if (Command.argsCount != 1) {
					throw new Error('This command requires ' + Command.argsCount + ' arguments.');
				}
				else {
					throw new Error('This command requires ' + Command.argsCount + ' argument.');
				}
			}

			// Process command
			let commandProcess = Command.process(MessageContext);

			// Did command return? Throw error.
			if (commandProcess) {
				throw new Error(commandProcess);
			}
		}
		else {
			// Invalid command
			throw new Error('Invalid command.');
		}
	}
}

module.exports = CommandParser;