const os = require('os');

module.exports = {
    "info": {
        description: "Bot info, etc...",
        process: (MessageContext) => {
            let infoMessage = '**__Bot Info:__**\n';

            infoMessage += '```';
            infoMessage += 'Version: ' + MessageContext.config.GitBranch + '-' + MessageContext.config.GitRevision;
            infoMessage += '\n';
            infoMessage += 'RAM Usage: ' + os.freemem() + '/' + os.totalmem();
            infoMessage += '\n';
            infoMessage += 'CPU Cores: ' + os.cpus().length;
            infoMessage += '\n';
            infoMessage += 'Uptime: ' + (process.uptime() + '').toHHMMSS();
            infoMessage += '```';

            MessageContext.message.reply(infoMessage);
        }
    },
    "invite": {
        description: "Invite the bot to your server!",
        process: (MessageContext) => {
            MessageContext.message.reply('https://discordapp.com/api/oauth2/authorize?client_id=' + MessageContext.client.user.id + '&permissions=8&scope=bot');
        }
    }
};