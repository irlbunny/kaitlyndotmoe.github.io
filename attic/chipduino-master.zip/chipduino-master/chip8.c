#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "chip8.h"

// Converted using bin2c
const char CHIP_ROM[38] = {
	0x60, 0x00, 0x61, 0x00, 0xa2, 0x22, 0xc2, 0x01, 0x32, 0x01, 0xa2, 
	0x1e, 0xd0, 0x14, 0x70, 0x04, 0x30, 0x40, 0x12, 0x04, 0x60, 0x00, 
	0x71, 0x04, 0x31, 0x20, 0x12, 0x04, 0x12, 0x1c, 0x80, 0x40, 0x20, 
	0x10, 0x20, 0x40, 0x80, 0x10
};

const int CHIP_ROM_length = 38;

unsigned char CHIP_Font[80] = { 
	0xF0, 0x90, 0x90, 0x90, 0xF0, // 0
	0x20, 0x60, 0x20, 0x20, 0x70, // 1
	0xF0, 0x10, 0xF0, 0x80, 0xF0, // 2
	0xF0, 0x10, 0xF0, 0x10, 0xF0, // 3
	0x90, 0x90, 0xF0, 0x10, 0x10, // 4
	0xF0, 0x80, 0xF0, 0x10, 0xF0, // 5
	0xF0, 0x80, 0xF0, 0x90, 0xF0, // 6
	0xF0, 0x10, 0x20, 0x40, 0x40, // 7
	0xF0, 0x90, 0xF0, 0x90, 0xF0, // 8
	0xF0, 0x90, 0xF0, 0x10, 0xF0, // 9
	0xF0, 0x90, 0xF0, 0x90, 0x90, // A
	0xE0, 0x90, 0xE0, 0x90, 0xE0, // B
	0xF0, 0x80, 0x80, 0x80, 0xF0, // C
	0xE0, 0x90, 0x90, 0x90, 0xE0, // D
	0xF0, 0x80, 0xF0, 0x80, 0xF0, // E
	0xF0, 0x80, 0xF0, 0x80, 0x80  // F
};

void CHIP_Initialize() {
	CHIP_PC     = 0x200;
	CHIP_Opcode = 0;
	CHIP_I      = 0;
	CHIP_SP     = 0;

	for (int i = 0; i < 80; ++i) {
		CHIP_Memory[i] = CHIP_Font[i];
	}

	for (int i = 0; i < CHIP_ROM_length; ++i) {
		CHIP_Memory[i + 512] = CHIP_ROM[i];
	}

	srand(time(NULL));
}

void CHIP_Step() {
	CHIP_Opcode = CHIP_Memory[CHIP_PC] << 8 | CHIP_Memory[CHIP_PC + 1];

	switch (CHIP_Opcode & 0xF000) {
		case 0x0000:
			switch (CHIP_Opcode & 0x000F)
			{
				case 0x0000:
					for (int i = 0; i < 2048; ++i)
						CHIP_Display[i] = 0x0;
					CHIP_DisplayFlag = true;
					CHIP_PC += 2;
					break;
				case 0x000E:
					--CHIP_SP;
					CHIP_PC = CHIP_Stack[CHIP_SP];		
					CHIP_PC += 2;
					break;
			}
			break;
		case 0x1000:
			CHIP_PC = CHIP_Opcode & 0x0FFF;
			break;
		case 0xA000:
			CHIP_I = CHIP_Opcode & 0x0FFF;
			CHIP_PC += 2;
			break;
		case 0x3000:
			if(CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] == (CHIP_Opcode & 0x00FF))
				CHIP_PC += 4;
			else
				CHIP_PC += 2;
			break;
		case 0x6000:
			CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] = CHIP_Opcode & 0x00FF;
			CHIP_PC += 2;
			break;
		case 0x2000:
			CHIP_Stack[CHIP_SP] = CHIP_PC;
			++CHIP_SP;
			CHIP_PC = CHIP_Opcode & 0x0FFF;
			break;
		case 0x9000:
			if(CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] != CHIP_V[(CHIP_Opcode & 0x00F0) >> 4])
				CHIP_PC += 4;
			else
				CHIP_PC += 2;
			break;
		case 0x0004:       
			if (CHIP_V[(CHIP_Opcode & 0x00F0) >> 4] > (0xFF - CHIP_V[(CHIP_Opcode & 0x0F00) >> 8]))
				CHIP_V[0xF] = 1;
			else
				CHIP_V[0xF] = 0;
			CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] += CHIP_V[(CHIP_Opcode & 0x00F0) >> 4];
			CHIP_PC += 2;          
			break;
		case 0x4000:
			if(CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] != (CHIP_Opcode & 0x00FF))
				CHIP_PC += 4;
			else
				CHIP_PC += 2;
			break;
		case 0x0033:
			CHIP_Memory[CHIP_I] = CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] / 100;
			CHIP_Memory[CHIP_I + 1] = (CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] / 10) % 10;
			CHIP_Memory[CHIP_I + 2] = (CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] % 100) % 10;
			CHIP_PC += 2;
			break;
		case 0xE000:
			switch(CHIP_Opcode & 0x00FF)
			{
				case 0x009E:
					if (CHIP_Key[CHIP_V[(CHIP_Opcode & 0x0F00) >> 8]] != 0)
						CHIP_PC += 4;
					else
						CHIP_PC += 2;
					break;
				case 0x00A1:
					if (CHIP_Key[CHIP_V[(CHIP_Opcode & 0x0F00) >> 8]] == 0)
						CHIP_PC += 4;
					else
						CHIP_PC += 2;
					break;
			}
			break;
		case 0xD000:		   
			{
				unsigned short CHIP_X = CHIP_V[(CHIP_Opcode & 0x0F00) >> 8];
				unsigned short CHIP_Y = CHIP_V[(CHIP_Opcode & 0x00F0) >> 4];
				unsigned short CHIP_H = CHIP_Opcode & 0x000F;
				unsigned short CHIP_DisplayPixel;

				CHIP_V[0xF] = 0;
				for (int CHIP_YL = 0; CHIP_YL < CHIP_H; CHIP_YL++) {
					CHIP_DisplayPixel = CHIP_Memory[CHIP_I + CHIP_YL];
					for (int CHIP_XL = 0; CHIP_XL < 8; CHIP_XL++) {
						if ((CHIP_DisplayPixel & (0x80 >> CHIP_XL)) != 0) {
							if (CHIP_Display[(CHIP_X + CHIP_XL + ((CHIP_Y + CHIP_YL) * 64))] == 1)
								CHIP_V[0xF] = 1;                                 
							CHIP_Display[CHIP_X + CHIP_XL + ((CHIP_Y + CHIP_YL) * 64)] ^= 1;
						}
					}
				}

				CHIP_DisplayFlag = true;
				CHIP_PC += 2;
			}
			break;
		case 0xC000:
			CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] = (rand() % 0xFF) & (CHIP_Opcode & 0x00FF);
			CHIP_PC += 2;
			break;
		case 0x7000:
			CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] += CHIP_Opcode & 0x00FF;
			CHIP_PC += 2;
			break;
		case 0xF000:
			switch (CHIP_Opcode & 0x00FF)
			{
				case 0x0007:
					CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] = CHIP_DelayTimer;
					CHIP_PC += 2;
					break;
				case 0x001E:
					if(CHIP_I + CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] > 0xFFF)
						CHIP_V[0xF] = 1;
					else
						CHIP_V[0xF] = 0;

					CHIP_I += CHIP_V[(CHIP_Opcode & 0x0F00) >> 8];
					CHIP_PC += 2;
					break;
				case 0x000A:
					{
						bool CHIP_KeyPRESS = false;

						for (int i = 0; i < 16; ++i) {
							if (CHIP_Key[i] != 0) {
								CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] = i;
								CHIP_KeyPRESS = true;
							}
						}

						if (!CHIP_KeyPRESS)						
							return;

						CHIP_PC += 2;					
					}
					break;
				case 0x0029:
					CHIP_I = CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] * 0x5;
					CHIP_PC += 2;
					break;
				case 0x0055:
					for (int i = 0; i <= ((CHIP_Opcode & 0x0F00) >> 8); ++i)
						CHIP_Memory[CHIP_I + i] = CHIP_V[i];

					CHIP_I += ((CHIP_Opcode & 0x0F00) >> 8) + 1;
					CHIP_PC += 2;
					break;
				case 0x0065:
					for (int i = 0; i <= ((CHIP_Opcode & 0x0F00) >> 8); ++i)
						CHIP_V[i] = CHIP_Memory[CHIP_I + i];

					CHIP_I += ((CHIP_Opcode & 0x0F00) >> 8) + 1;
					CHIP_PC += 2;
					break;
				case 0x0015:
					CHIP_DelayTimer = CHIP_V[(CHIP_Opcode & 0x0F00) >> 8];
					CHIP_PC += 2;
					break;
			}
			break;
		case 0x8000:
			switch (CHIP_Opcode & 0x000F)
			{
				case 0x0000:
					CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] = CHIP_V[(CHIP_Opcode & 0x00F0) >> 4];
					CHIP_PC += 2;
					break;
				case 0x0002:
					CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] &= CHIP_V[(CHIP_Opcode & 0x00F0) >> 4];
					CHIP_PC += 2;
					break;
				case 0x0003:
					CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] ^= CHIP_V[(CHIP_Opcode & 0x00F0) >> 4];
					CHIP_PC += 2;
					break;
				case 0x0005:
					if(CHIP_V[(CHIP_Opcode & 0x00F0) >> 4] > CHIP_V[(CHIP_Opcode & 0x0F00) >> 8]) 
						CHIP_V[0xF] = 0;
					else 
						CHIP_V[0xF] = 1;					
					CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] -= CHIP_V[(CHIP_Opcode & 0x00F0) >> 4];
					CHIP_PC += 2;
					break;
				case 0x0007:
					if(CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] > CHIP_V[(CHIP_Opcode & 0x00F0) >> 4])
						CHIP_V[0xF] = 0;
					else
						CHIP_V[0xF] = 1;
					CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] = CHIP_V[(CHIP_Opcode & 0x00F0) >> 4] - CHIP_V[(CHIP_Opcode & 0x0F00) >> 8];				
					CHIP_PC += 2;
					break;
				case 0x000E:
					CHIP_V[0xF] = CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] >> 7;
					CHIP_V[(CHIP_Opcode & 0x0F00) >> 8] <<= 1;
					CHIP_PC += 2;
					break;
			}
			break;
	}

	if (CHIP_DelayTimer > 0)
		--CHIP_DelayTimer;

	if (CHIP_SoundTimer > 0) {
		if (CHIP_SoundTimer == 1) {
      //TODO: Implement beeper
		}
		--CHIP_SoundTimer;
	}  
}
