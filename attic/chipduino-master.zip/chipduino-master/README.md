# chipduino
A CHIP-8 (interpreter) emulator for Arduino MEGA 2560.

Emulation is a bit slow due to using serial at 115200 baud, though it should be possible to port this interpreter to other platforms.

Contains Maze ROM data in chip8.c