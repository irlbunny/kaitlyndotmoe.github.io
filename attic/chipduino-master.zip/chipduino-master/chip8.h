#ifndef __CHIP8_H
#define __CHIP8_H

#include <stdbool.h>

unsigned short CHIP_Opcode;
unsigned char CHIP_Memory[4096];
unsigned char CHIP_V[16];
unsigned short CHIP_I;
unsigned short CHIP_PC;
unsigned char CHIP_Display[64 * 32];
unsigned char CHIP_DelayTimer;
unsigned char CHIP_SoundTimer;
unsigned short CHIP_Stack[16];
unsigned short CHIP_SP;
unsigned char CHIP_Key[16];
bool CHIP_DisplayFlag;

void CHIP_Initialize();
void CHIP_Step();

#endif
