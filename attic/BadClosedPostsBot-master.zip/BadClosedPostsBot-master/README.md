# BadClosedPostsBot
Posting the worst posts from your favorite Miiverse clone!
