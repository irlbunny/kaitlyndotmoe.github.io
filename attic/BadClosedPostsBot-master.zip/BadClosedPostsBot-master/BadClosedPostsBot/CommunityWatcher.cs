﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BadClosedPostsBot
{
    class CommunityWatcher
    {
        private string communityEndpoint = "https://closed.pizza/communities/";
        private List<Community> communitiesWatchList { get; set; }
        private List<Word> watchedWords { get; set; }

        public CommunityWatcher(List<Community> communitiesWatchList, List<Word> watchedWords)
        {
            this.communitiesWatchList = communitiesWatchList;
            this.watchedWords = watchedWords;

            // Start new thread to avoid slowdowns
            Thread watchThread = new Thread(new ThreadStart(Run));
            watchThread.Start();
        }

        private void Run()
        {
            WebClient client = new WebClient();

            while (true)
            {
                foreach (Community community in communitiesWatchList)
                {
                    // downloading community page data
                    Console.WriteLine("Downloading community data | ID = " + community.Id + ", Name = " + community.Name);
                    string communityData = "";
                    try
                    {
                        communityData = client.DownloadString(communityEndpoint + community.Id);
                    }
                    catch (Exception e) { }
                    if (string.IsNullOrEmpty(communityData))
                    {
                        return;
                    }
                    Console.WriteLine("Successfully downloaded community data | ID = " + community.Id + ", Name = " + community.Name);

                    // parse html
                    HtmlDocument parsedData = new HtmlDocument();
                    parsedData.LoadHtml(communityData);
                    IEnumerable<HtmlNode> postNodes = parsedData.DocumentNode.Descendants("div")
                        .Where(d => d.GetAttributeValue("class", "")
                        .Contains("post post-subtype-default trigger"));

                    //foreach every node
                    foreach (HtmlNode node in postNodes)
                    {
                        // Console.WriteLine(node.OuterHtml);
                        if (node.Attributes["data-href"] != null)
                        {
                            // Scrape post
                            new PostScrape(node.Attributes["data-href"].Value, watchedWords);
                        }
                    }

                    // sleep
                    Thread.Sleep(2000);
                }
            }
        }
    }
}
