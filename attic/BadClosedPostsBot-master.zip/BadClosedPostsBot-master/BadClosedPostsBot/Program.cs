﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BadClosedPostsBot
{
    class Program
    {
        public static List<Community> communitiesWatchList = new List<Community>();
        public static List<Word> watchedWordsList = new List<Word>();

        static void Main(string[] args)
        {
            // watched communities
            communitiesWatchList.Add(new Community(6, "Anything Goes Community"));
            communitiesWatchList.Add(new Community(91, "Closedverse School Community"));
            communitiesWatchList.Add(new Community(119, "JoJo's Bizarre Adventure Community"));

            // watched words
            watchedWordsList.Add(new Word("sex"));
            watchedWordsList.Add(new Word("cunt"));
            watchedWordsList.Add(new Word("rape"));
            watchedWordsList.Add(new Word("slut"));
            watchedWordsList.Add(new Word("cum"));
            watchedWordsList.Add(new Word("cum inside"));
            watchedWordsList.Add(new Word("penis"));
            watchedWordsList.Add(new Word("thrusting"));
            watchedWordsList.Add(new Word("vagina"));
            watchedWordsList.Add(new Word("fuck me"));
            watchedWordsList.Add(new Word("arian is god"));

            //start bot
            new CommunityWatcher(communitiesWatchList, watchedWordsList);
        }
    }
}
