﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BadClosedPostsBot
{
    class PostScrape
    {
        private string closedEndpoint = "https://closed.pizza";
        public string postLink { get; set; }
        private List<Word> watchedWords { get; set; }

        public PostScrape(string postLink, List<Word> watchedWords)
        {
            this.postLink = postLink;
            this.watchedWords = watchedWords;

            Thread scrapeThread = new Thread(new ThreadStart(Run));
            scrapeThread.SetApartmentState(ApartmentState.STA);
            scrapeThread.Start();
        }

        private void Run()
        {
            WebClient client = new WebClient();

            // sick haxx
            int postId = Int32.Parse(postLink.Replace("/posts/", ""));

            // check if this post has already been posted
            bool exists = false;
            string line;
            StreamReader file = new StreamReader("posted.txt");
            while ((line = file.ReadLine()) != null)
            {
                if (line == postId.ToString())
                {
                    exists = true;
                    break;
                }
            }
            file.Dispose();
            if (exists) return;

            // downloading post page data
            Console.WriteLine("Downloading post data | ID = " + postId);
            string postData = "";
            try
            {
                postData = client.DownloadString(closedEndpoint + postLink);
            }
            catch (Exception e) { }
            if (string.IsNullOrEmpty(postData))
            {
                return;
            }
            Console.WriteLine("Successfully downloaded post data | ID = " + postId);

            // parse html
            HtmlDocument parsedData = new HtmlDocument();
            parsedData.LoadHtml(postData);
            foreach (var brTag in parsedData.DocumentNode.SelectNodes("//br"))
                brTag.Remove();
            IEnumerable<HtmlNode> postNodes = parsedData.DocumentNode.Descendants("p")
                .Where(d => d.GetAttributeValue("class", "")
                .Contains("post-content-text"));

            foreach (HtmlNode node in postNodes)
            {
                string post = node.InnerHtml;
                foreach (Word word in watchedWords)
                {
                    if (post.Contains(word.Text))
                    {
                        // post contains watched word
                        Console.WriteLine("Post contains word, Word = " + word.Text + ", ID = " + postId);
                        string text = node.InnerHtml;

                        // if text is above 24 chars minify it
                        if (text.Length > 24)
                            text = text.Substring(0, 24) + "...";

                        Console.WriteLine("Post Text: " + text + " | ID = " + postId);

                        // post to cedar
                        Console.WriteLine("Posting to Cedar...");
                        new CedarPost("<YOUR_GRAHAM_COOKIE>", "#BadClosedversePosts" + Environment.NewLine + text + " | " + closedEndpoint + postLink, 78519322);
                        Console.WriteLine("Done!");

                        // append postId to make sure this post has already been posted
                        File.AppendAllText("posted.txt", postId.ToString() + Environment.NewLine);
                    }
                }
            }
        }
    }
}
