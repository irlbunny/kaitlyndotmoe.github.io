﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BadClosedPostsBot
{
    class Word
    {
        public string Text { get; set; }

        public Word(string Text)
        {
            this.Text = Text;
        }
    }
}
