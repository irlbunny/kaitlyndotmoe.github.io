﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BadClosedPostsBot
{
    //taken from my unfinished library for cedar in C#
    class CedarPost
    {
        private WebClient cedarClient;
        private string cedarEndpoint = "https://cedar.doctor";

        public CedarPost(string graham, string message, int titleId)
        {
            cedarClient = new WebClient();
            cedarClient.Headers.Add(HttpRequestHeader.Cookie, "graham=" + graham);
            PostMessage(message, titleId);
        }

        private void PostMessage(string message, int titleId)
        {
            NameValueCollection FormData = new NameValueCollection();
            FormData["title_id"] = titleId.ToString();
            FormData["text_data"] = message;

            cedarClient.UploadValues(cedarEndpoint + "/postText.php", "POST", FormData);
        }
    }
}
