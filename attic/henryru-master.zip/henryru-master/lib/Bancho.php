<?php
require_once(__DIR__ . DIRECTORY_SEPARATOR . "Packet.php");

$protocolVersion = 19;

$headers = getallheaders();
$postData = file_get_contents("php://input");

header("cho-token: " . "osu");
header("cho-protocol: " . $protocolVersion);

if (!isset($headers["osu-token"]))
{
	$lines = explode("\n", $postData);
	if (count($lines) != 4)
	{
		die(Packet::Create(5, -5));
	}
	else
	{
		$output  = Packet::Create(92, 0); // Chat ban status
		$output .= Packet::Create(5, 1); // User ID

		$output .= Packet::Create(75, $protocolVersion); // Protocol version

		$output .= Packet::Create(71, 20); // User permissions
		$output .= Packet::Create(83, array(
			"userId"      => 1,
			"username"    => $lines[0],
			"timezone"    => 24,
			"countryCode" => 0,
			"tags"        => 20,
			"longitude"   => 0,
			"latitude"    => 0,
			"rank"        => 1
		));
		$output .= Packet::Create(11, array(
			"userId"          => 1,
			"status"          => 0,
			"statusText"      => "",
			"beatmapChecksum" => "",
			"currentMods"     => 0,
			"playMode"        => 0,
			"beatmapId"       => 0,
			"rankedScore"     => 0,
			"accuracy"        => 0,
			"playcount"       => 0,
			"totalScore"      => 0,
			"rank"            => 1,
			"performance"     => 0,
		));

		$output .= Packet::Create(83, array(
			"userId"      => 2,
			"username"    => "Weeaboot",
			"timezone"    => 24,
			"countryCode" => 0,
			"tags"        => 20,
			"longitude"   => 0,
			"latitude"    => 0,
			"rank"        => 0
		));

		$output .= Packet::Create(96, array(1, 2));
		
		$output .= Packet::Create(89);
		$output .= Packet::Create(64, "#osu");
		$output .= Packet::Create(64, "#updates");

		$output .= Packet::Create(7, array(
			"sendingClient" => "Weeaboot",
			"message"       => "Hello! Welcome to Henryru beta.",
			"target"        => "#updates",
			"senderId"      => 2
		));
		
		$output .= Packet::Create(24, "Welcome to Henryru!");
		
		echo($output);
	}
}
else
{
	// ...
}