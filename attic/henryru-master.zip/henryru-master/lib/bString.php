<?php
require_once(__DIR__ . DIRECTORY_SEPARATOR . "Leb128.php");

class bString
{
    public static function Encode($string)
    {
        $encoded  = pack("C*", 11);
        $encoded .= Leb128::uencode(strlen($string));
        $encoded .= $string;

        return $encoded;
    }
}