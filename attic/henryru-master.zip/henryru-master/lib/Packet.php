<?php
require_once(__DIR__ . DIRECTORY_SEPARATOR . "bString.php");

class Packet
{
    public static function Create($packetId, $input = null)
    {
        $packetOutput = "";
        $packetData   = "";

        switch ($packetId)
        {
            // bString
            case 24: // Bancho_Announce
            case 64: // Bancho_ChannelJoinSuccess
            case 76: // Bancho_TitleUpdate
            $packetData .= bString::Encode($input);
            break;

            case 7: // Bancho_SendMessage
            $packetData .= bString::Encode($input["sendingClient"]);
            $packetData .= bString::Encode($input["message"]);
            $packetData .= bString::Encode($input["target"]);
            $packetData .= pack("i*", $input["senderId"]);
            break;

            case 11: // Bancho_HandleOsuUpdate
            $packetData .= pack("i*", $input["userId"]);

            // bStatusUpdate
            $packetData .= pack("C*", $input["status"]);
            $packetData .= bString::Encode($input["statusText"]);
            $packetData .= bString::Encode($input["beatmapChecksum"]);
            $packetData .= pack("I*", $input["currentMods"]);
            $packetData .= pack("C*", $input["playMode"]);
            $packetData .= pack("i*", $input["beatmapId"]);

            $packetData .= pack("l*", $input["rankedScore"]);
            $packetData .= pack("f*", $input["accuracy"]);
            $packetData .= pack("i*", $input["playcount"]);
            $packetData .= pack("l*", $input["totalScore"]);
            $packetData .= pack("i*", $input["rank"]);
            $packetData .= pack("s*", $input["performance"]);
            break;

            case 83: // Bancho_UserPresence
            $packetData .= pack("i*", $input["userId"]);
            $packetData .= bString::Encode($input["username"]);
            $packetData .= pack("C*", $input["timezone"]);
            $packetData .= pack("C*", $input["countryCode"]);
            $packetData .= pack("C*", $input["tags"]);
            $packetData .= pack("f*", $input["longitude"]);
            $packetData .= pack("f*", $input["latitude"]);
            $packetData .= pack("i*", $input["rank"]);
            break;

            // Int32[] (short length, Int32[length])
            case 96:
            $packetData .= pack("s*", sizeof($input));

            foreach ($input as $value)
            {
                $packetData .= pack("i*", $value);
            }
            break;

            // Int32
            case 5: // Bancho_LoginReply
            case 71: // Bancho_LoginPermissions
            case 75: // Bancho_ProtocolNegotiation
            case 92: // Bancho_BanInfo
            $packetData .= pack("i*", $input);
            break;
        }

        $packetOutput .= pack("S*", $packetId); // Packet ID
        $packetOutput .= pack("C*", 0); // Compression (Unused)
        $packetOutput .= pack("I*", strlen($packetData)); // Data length
        $packetOutput .= $packetData; // Append packet data

        return $packetOutput; // Return packet header + packet data
    }
}