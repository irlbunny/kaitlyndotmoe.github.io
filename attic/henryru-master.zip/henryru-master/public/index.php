<?php
require_once("../lib/AltoRouter.php");
require_once("../lib/Core.php");
session_start();

$router = new AltoRouter();
$twig = Core::Twig_Initialize();

$router->addRoutes(array(
    array("POST", "/", "../lib/Bancho.php", "Bancho-server"),
    array("GET", "/", "home.php", "Home-page")
));

// Match the current request
$match = $router->match(urldecode($_SERVER["REQUEST_URI"]));
if ($match) {
    foreach ($match["params"] as &$param) {
        ${key($match["params"])} = $param;
    }
    require_once $match["target"];
} else {
    http_response_code(404);
    exit($twig->render("error.twig", ["message" => "Page not found."]));
}