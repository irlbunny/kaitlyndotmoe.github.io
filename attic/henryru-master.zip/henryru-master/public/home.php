<?php
echo $twig->render("home.twig");