class Helpers {
    public:
        Helpers();
        ~Helpers();

        int Resize(int Value);
};