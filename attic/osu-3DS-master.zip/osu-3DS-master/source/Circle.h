#define HITCIRCLE_TEXTURE   00051
#define HITOVERLAY_TEXTURE  00052
#define HITAPPROACH_TEXTURE 00053
#define HIT_300             00054
#define HIT_100             00055
#define HIT_50              00056
#define HIT_0               00057

class Circle {
    public:
        Circle();
        ~Circle();

        void LoadTextures();
        void DrawCircle(int X, int Y);
        void DrawApproach(int X, int Y, float Size);
        void DrawCircleAndApproach(int X, int Y, long Timing, long CurrentTiming, double ApproachRate);
    private:
        void   Reset();
        double DifficultyRange(double Difficulty, double Min, double Mid, double Max);
        
        float  Size         = 0.5f;
        float  ApproachSize = 1.0f;
        bool   Draw         = true;
        double HitRange     = 300;
        int    MSTick       = 0;
        long   StartTime    = 0;
};