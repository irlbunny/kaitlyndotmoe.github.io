#include "Circle.h"
#include "pp2d/pp2d.h"

Circle::Circle() { }
Circle::~Circle() { }

void Circle::LoadTextures() {
	pp2d_load_texture_png(HITCIRCLE_TEXTURE, "romfs:/default/hitcircle.png");
	pp2d_load_texture_png(HITOVERLAY_TEXTURE, "romfs:/default/hitcircleoverlay.png");
	pp2d_load_texture_png(HITAPPROACH_TEXTURE, "romfs:/default/approachcircle.png");
}

void Circle::DrawCircle(int X, int Y) {
	int CenterX = X - (int)(64 * Size);
	int CenterY = Y - (int)(64 * Size);
	pp2d_draw_texture_scale(HITCIRCLE_TEXTURE, CenterX, CenterY, Size, Size);
	pp2d_draw_texture_scale(HITOVERLAY_TEXTURE, CenterX, CenterY, Size, Size);
}

void Circle::DrawApproach(int X, int Y, float Size) {
	int CenterX = X - (int)(64 * Size);
	int CenterY = Y - (int)(64 * Size);
	pp2d_draw_texture_scale(HITAPPROACH_TEXTURE, CenterX, CenterY, Size, Size);
}

void Circle::DrawCircleAndApproach(int X, int Y, long Timing, long CurrentTiming, double ApproachRate) {
	double PreApproachTime    = Circle::DifficultyRange(ApproachRate, 1800, 1200, 450);
	double ActualApproachRate = PreApproachTime > 1200 ? (1800 - PreApproachTime) / 120 : (1200 - PreApproachTime) / 150 + 5;
	double ApproachTime       = Circle::DifficultyRange(ActualApproachRate, 1800, 1200, 450);

	if (CurrentTiming + (ApproachTime) + 100 > Timing && CurrentTiming - (ApproachTime) < Timing) {
		if (Draw) {
			if (CurrentTiming + (ApproachTime) + 100 > Timing && CurrentTiming - (ApproachTime / 10) < Timing) {
				if (StartTime == 0) {
					StartTime = CurrentTiming;
					MSTick    = CurrentTiming - StartTime;
				}

				Circle::DrawCircle(X, Y);

				long  Difference          = (CurrentTiming - Timing);
				float Doub                = 2 * ApproachTime;
				float CurrentApproachSize = (-1 * (Difference / Doub)) + 0.5;

				if (Difference > (-1 * ApproachTime * HitRange) && Difference < 0) {
					MSTick = CurrentTiming - StartTime;
					Circle::DrawApproach(X, Y, CurrentApproachSize);
				} else if (CurrentTiming + (ApproachTime) > Timing && Difference < 0) {
					Circle::DrawApproach(X, Y, 1.0f);
				}
			}
		}
	} else {
		Circle::Reset();
	}
}

void Circle::Reset() {
	Draw         = true;
	ApproachSize = 1.0f;
	MSTick       = 0;
	StartTime    = 0;
}

double Circle::DifficultyRange(double Difficulty, double Min, double Mid, double Max) {
	if (Difficulty > 5)
		return Mid + (Max - Mid) * (Difficulty - 5) / 5;
	if (Difficulty < 5)
		return Mid - (Mid - Min) * (5 - Difficulty) / 5;
	return Mid;
}