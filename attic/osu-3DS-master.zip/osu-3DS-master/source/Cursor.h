#define CURSOR_TEXTURE 00001

class Cursor {
    public:
        Cursor();
        ~Cursor();

        void LoadTextures();
        void Draw();
    private:
        float Size     = 0.5f;
        int   X        = 0;
        int   Y        = 0;
        float Rotation = 0.0f;
        int   Extend   = 0;
        bool  Extended = false;
};
