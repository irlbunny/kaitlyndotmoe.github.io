#include <3ds.h>
#include "Cursor.h"
#include "pp2d/pp2d.h"

Cursor::Cursor() { }
Cursor::~Cursor() { }

void Cursor::LoadTextures() {
	pp2d_load_texture_png(CURSOR_TEXTURE, "romfs:/default/cursor.png");
}

void Cursor::Draw() {
	touchPosition Touch;
	hidTouchRead(&Touch);

	if (Touch.px != 0 && Touch.py != 0) {
		Extended = false;
		X        = Touch.px - (int)(40 * Size);
		Y        = Touch.py - (int)(40 * Size);
		pp2d_draw_texture_scale_rotate(CURSOR_TEXTURE, X, Y, Size, Size, Rotation);
	} else if (Extend > 0) {
		pp2d_draw_texture_scale_rotate(CURSOR_TEXTURE, X, Y, Size, Size, Rotation);
		Extend -= 1;
	} else {
		if (!Extended) {
			Extended = true;
			Extend   = 20;
		}
		return;
	}

	Rotation += 0.8f;
}