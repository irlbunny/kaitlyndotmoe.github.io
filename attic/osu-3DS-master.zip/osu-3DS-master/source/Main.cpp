#include <3ds.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "pp2d/pp2d.h"
#include "Cursor.h"
#include "Helpers.h"
#include "Circle.h"

Cursor  MainCursor;
Circle  HitCircles;
Helpers MainHelper;

long long StartTime = -1;
long      CurrentTime;

int main() {
	if (StartTime == -1) {
		StartTime = osGetTime();
	}

	// Initialize and load textures
	romfsInit();
	pp2d_init();

	consoleInit(GFX_TOP, NULL);

	MainCursor.LoadTextures();
	HitCircles.LoadTextures();

	pp2d_set_screen_color(GFX_BOTTOM, ABGR8(255, 51, 51, 51));

	while (aptMainLoop() && !(hidKeysDown() & KEY_START)) {
		hidScanInput();

		// Begin frame
		pp2d_begin_draw(GFX_BOTTOM);
			pp2d_draw_text(0, 0, 0.5f, 0.5f, RGBA8(255, 255, 255, 255), "osu!3DS");

			// C++ code

			MainCursor.Draw(); // Always draw cursor on top of stuff
		pp2d_end_draw();

		CurrentTime = osGetTime() - StartTime; // Set our current time

		// Debug info
		printf("\x1b[1;1HTIME:     %6ld  %6lld", CurrentTime, StartTime);
		printf("\x1b[3;1HCPU:     %6.2f%%\x1b[K", C3D_GetProcessingTime() * 6.0f);
		printf("\x1b[4;1HGPU:     %6.2f%%\x1b[K", C3D_GetDrawingTime() * 6.0f);
		printf("\x1b[5;1HCmdBuf:  %6.2f%%\x1b[K", C3D_GetCmdBufUsage() * 100.0f);
	}

	// Kill graphics enviorment
	pp2d_exit();
	return 0;
}