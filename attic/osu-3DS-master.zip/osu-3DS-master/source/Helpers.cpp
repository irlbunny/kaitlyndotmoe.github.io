#include "Helpers.h"

Helpers::Helpers() { }
Helpers::~Helpers() { }

int Helpers::Resize(int Value)
{
	return (Value * 5) >> 3;
}