# osu!3DS
osu!3DS is a homebrew port of osu! for the Nintendo 3DS. It's currently in very early stages. Feel free to submit issues and pull requests.
### Installation
- copy osu! assets into `/romfs/default`
- build using devkitpro
- load into citra or a 3ds with homebrew