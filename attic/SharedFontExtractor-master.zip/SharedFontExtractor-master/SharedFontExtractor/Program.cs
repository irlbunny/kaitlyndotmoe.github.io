﻿using System;
using System.IO;

namespace SharedFontExtractor
{
    class Program
    {
        private static FontRegion[] FontRegions = {
            // Standard                                                // ChineseSimplified
            new FontRegion { Offset = 0x00000008, Size = 0x001fe764 }, new FontRegion { Offset = 0x001fe774, Size = 0x00773e58 },

            // ExtendedChineseSimplified                               // ChineseTraditional
            new FontRegion { Offset = 0x009725d4, Size = 0x0001aca8 }, new FontRegion { Offset = 0x0098d284, Size = 0x00369cec },

            // Korean                                                  // NintendoExtended
            new FontRegion { Offset = 0x00cf6f78, Size = 0x0039b858 }, new FontRegion { Offset = 0x010927d8, Size = 0x00019e80 },
        };

        private static string[] FontNames = {
            "Standard",
            "ChineseSimplified",
            "ExtendedChineseSimplified",
            "ChineseTraditional",
            "Korean",
            "NintendoExtended"
        };

        static void Main(string[] args)
        {
            Console.WriteLine("============- SharedFontExtractor by Cyuubi -============");

            if (args == null || args.Length == 0)
            {
                Console.WriteLine("Usage: SharedFontExtractor.exe <shared_font.bin>");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Extracting shared fonts...");

            using (FileStream FontStream = File.Open(args[0], FileMode.Open))
            using (BinaryReader FontReader = new BinaryReader(FontStream))
            {
                for (int Index = 0; Index < FontRegions.Length; Index++)
                {
                    FontStream.Seek(FontRegions[Index].Offset, SeekOrigin.Begin);
                    File.WriteAllBytes($"Font{FontNames[Index]}.ttf", FontReader.ReadBytes(FontRegions[Index].Size));
                    Console.WriteLine($"Extracted \"Font{FontNames[Index]}.ttf\"");
                }
            }

            Console.WriteLine("Done! Press any key to exit...");
            Console.ReadKey();
        }
    }
}
