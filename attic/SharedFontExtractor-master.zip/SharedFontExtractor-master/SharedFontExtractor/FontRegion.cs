﻿namespace SharedFontExtractor
{
    struct FontRegion
    {
        public int Offset;
        public int Size;
    }
}
