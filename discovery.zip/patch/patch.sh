#!/usr/bin/env bash

rm -f code.ips
armips patch.s
flips/flips --create --ips code.bin code_patched.bin code.ips
rm -f code_patched.bin